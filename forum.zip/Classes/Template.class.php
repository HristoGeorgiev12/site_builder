<?php
/**
 * Created by PhpStorm.
 * User: Georgievi
 * Date: 16.5.2016 г.
 * Time: 16:01 ч.
 */

class Template {

    protected $connection;

    function __construct() {
        $this->connection=new Connect('forum');
    }

    //Merge Get and Post values into one array;
    public $aParams = array();
    public function setParams($parameters) {
        $this->aParams = $parameters;
    }

    public function getParams($key) {
        return isset($_GET[$key])? $this->aParams[$key]:"";
    }


    protected function selectAll($table) {
        $conn = $this->connection;

        $query = "SELECT * FROM $table";

        $conn = $conn->connect->prepare($query);

        $conn->execute();

        return $conn->fetchAll();
    }


    public function Title() {
        return "Test";
    }

    public function Body() {
        ?>
            <h1>Test Forum</h1>
        <?php
    }

    public function HTML() {

        ?>
            <html>
                <head>
<!--                    Meta-->
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

                    <title>
                        <?php
                            if(isset($this->aParams["page"])) {
                                echo $this->aParams["page"];
                            }else {
                                echo $this->Title();
                            }
                        ?>
                    </title>

<!--                    StylesSheets-->
                    <link rel="stylesheet" type="text/css" href="style/style.css">
                    <link rel="stylesheet" type="text/css" href="style/bootstrap.css">

<!--                    JS Scripts-->
                    <script src="http://code.jquery.com/jquery-2.2.0.min.js"></script>
                    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
                </head>
                <body>
                <div class="container">
                    <h4><?php
                           echo isset($_SESSION['user_name'])?"Здравей, ". $_SESSION['user_name']:null;
                        ?></h4><br>



                    <nav class="navbar navbar-default">
                        <div class="container-fluid">
                            <div class="navbar-header">
                                <a class="navbar-brand" href="#">Навигационно меню</a>
                            </div>
                            <ul class="nav navbar-nav navbar-right">
                                <li class="active"><a href="?page=index">Начална страница</a></li>
                                <li><a id="createNewPost">Създай нова тема</a></li>
                                <li><a href="?page=searchPosts">Търсачка</a></li>
                                <?php
                                    if(isset($_SESSION["user_id"])) {
                                        echo '<li><a href="?page=login&logOut=true">Излизане</a></li>';
                                    }else {
                                        echo "<li><a href='?page=login'>Впиши се</a></li>";
                                    }
                                ?>
                            </ul>
                        </div>
                    </nav>
                        <?= $this->Body();?>

                </div><!--End of container-->

                <script>
                    var logged = <?= isset($_SESSION['user_id'])?$_SESSION['user_id']: 0; ?> ;

                    $("#writeComment").on("click", function() {
                        if(!logged) {
                            var promptResult = confirm("Не може да коментирате без да сте вписани! Жлаете ли да се впишете?");
                            if(promptResult == true) {
                                window.location.replace("?page=login");
                            }
                        }else {
                            $("#writeCommentForm").toggle("slow");
                        }
                    });

                    $("#createNewPost").on("click", function() {
                        if(!logged) {
                            var promptResult = confirm("Не може да коментирате без да сте вписани! Жлаете ли да се впишете?");
                            if(promptResult == true) {
                                window.location.replace("?page=login");
                            }else {
                                false;
                            }
                        }else {
                            window.location.replace("?page=createPost");
                        }
                    });

                    $(".reply_to_comment").one("click", function() {
                        var comment_id = $(this).parent().attr('id');
                        var current_url = '<?= $_SERVER['QUERY_STRING'];?>';

                        $(this).parent().append("<form action='?"+current_url+"' method='post'><input type='hidden' name='comment_id' value='"+comment_id+"'><textarea name='reply_comment'></textarea><input type='submit' name='submit_reply' value='Отговори'> </form>");
                    });



                </script>

                <?php
                    if($this->aParams['page'] !== 'login') $_SESSION['lastPage'] = $_SERVER['QUERY_STRING'];
                ?>

                </body>
            </html>
        <?php
    }
}