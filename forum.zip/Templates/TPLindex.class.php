<?php
/**
 * Created by PhpStorm.
 * User: Georgievi
 * Date: 16.5.2016 г.
 * Time: 18:11 ч.
 */

class TPLindex extends Template {

    private function showPost($cat) {
        $conn = $this->connection;

        $query = "SELECT
                      p.id,
                      p.post_name,
                      p.date_created,
                      u.user_name AS userName
                  FROM posts p
                  INNER JOIN users u
                  ON u.id = p.user_id
                  WHERE p.category_id=:cat
                  ORDER BY date_created DESC
                  LIMIT 5";

        $conn = $conn->connect->prepare($query);
        $conn->bindParam(":cat",$cat, PDO::PARAM_INT);

        $conn->execute();
        return $conn->fetchAll(PDO::FETCH_ASSOC);
    }

    private function showCategories() {
        $conn = $this->connection;

        $query = "SELECT
                    c.id AS catId,
                    c.category_name AS catName,
                    COUNT(p.id) as countPosts
                  FROM categories c
                  LEFT JOIN posts p
                  ON p.category_id = c.id
                  GROUP BY c.id
                  ORDER BY c.id";

        $conn = $conn->connect->prepare($query);

        $conn->execute();
        return $conn->fetchAll(PDO::FETCH_ASSOC);
    }

    public function Title() {
        return "Main Page";
    }

    public function Body() {
        ?>
            <div id="categories">
                <?php
                    $result = $this->showCategories();

                    foreach($result as $catValue) {


                        $resultId = $catValue['catId'];
                        $resultUsername = $catValue['catName'];
                        $resultCountPosts = $catValue['countPosts'];


                        ?>
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th><?= "<a href='?page=posts&cat={$resultId}'>{$resultUsername}</a> -{$resultCountPosts} -Поста<br>";?></th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                                foreach($this->showPost($resultId) as $postValue) {
                                    $postId = $postValue['id'];
                                    $postName = $postValue['post_name'];
                                    $creatorAndDare = "Създадена от:". $postValue['userName']." на ". $postValue['date_created'];

                                    echo " <tr><td><a href='?page=comments&post={$postId}'>{$postName}</a> {$creatorAndDare}</td></tr>";
                                }
                            ?>

                            </tbody>
                        </table>
                        <?php

//                        echo "<a href='?page=posts&cat={$resultValue}'>{$resultValue}</a><br>";
                    }
                ?>
            </div>






        <?php
    }
}