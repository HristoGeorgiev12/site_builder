<?php
/**
 * Created by PhpStorm.
 * User: Georgievi
 * Date: 16.5.2016 г.
 * Time: 18:17 ч.
 */

class TPLlogin extends Template {
    private function loginCheck($table, $user_name, $user_password) {
        $conn = $this->connection;

        $query = "SELECT * FROM $table WHERE user_name=? AND user_password=?";

        $conn = $conn->connect->prepare($query);

        $user_password = md5($user_password);
        $conn->bindParam(1, $user_name, PDO::PARAM_STR);
        $conn->bindParam(2, $user_password, PDO::PARAM_STR);

        $conn->execute();
        return $conn->fetch();
    }

    public function Title() {
        return "Login";
    }

    public function Body() {

        if(isset($_SESSION['notLogged'])) {
            echo "Трябва да се впишите да да създавате теми или да коментирате постове";
            unset($_SESSION['notLogged']);
        }


        if(isset($this->aParams['login_submit'])) {
            $check = $this->loginCheck('users',
                $this->aParams['user_name'],
                $this->aParams['user_password']);

            $lastUrl = "?".$_SESSION['lastPage'];


            if($check) {
                $_SESSION["user_id"] = $check['id'];
                $_SESSION["user_name"] = $check['user_name'];
                header("Location: $lastUrl");
            } else {
                echo "Грешно Потребителско име или Парола.";
            }
        }

        if(isset($this->aParams['logOut'])) {
            session_destroy();
            header("Location: ?page=index");
        }


        ?>
            <h2>Вписване</h2><br>
        <form action="" method="post">
            <input type="text" name="user_name" placeholder="Потребителско име" required><br>
            <input type="password" name="user_password" placeholder="Парола" required><br>
            <input type="submit" name="login_submit" value="Впиши ме">
        </form>

        <h4>Нямате регистрация</h4><br>
        <a href="?page=registration">Регистрирай се!</a>

        <?php
    }
}