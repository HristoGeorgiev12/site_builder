<?php
/**
 * Created by PhpStorm.
 * User: Georgievi
 * Date: 17.5.2016 г.
 * Time: 18:08 ч.
 */

class TPLposts extends Template {

    private function showPosts($cat) {
        $conn = $this->connection;

        $query = "SELECT
                    p.id,
                    cat.category_name,
                    p.post_name,
                    COUNT(com.id) AS sumComments,
                    (SELECT
                        COUNT(id)
                    FROM posts
                    WHERE category_id=1) AS sumPosts,
                    u.user_name,
                    p.date_created
                  FROM categories cat
                  LEFT JOIN posts p
                  ON p.category_id=cat.id
                  INNER JOIN users u
                  ON u.id=p.user_id
                  LEFT JOIN comments com
                  ON com.post_id=p.id
                  WHERE cat.id = :cat
                  GROUP BY p.id
                  ORDER BY p.id DESC ";

        $conn = $conn->connect->prepare($query);
        $conn->bindParam(":cat",$cat, PDO::PARAM_INT);
        $conn->execute();

        return $conn->fetchAll(PDO::FETCH_ASSOC);

    }

    public function Title() {
        return "Posts";
    }

    public function Body() {
            $aQuery = $this->showPosts($this->aParams['cat']);

        ?>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <td colspan="4">
                        <?= $aQuery[0]["category_name"]."// Общ Брой Теми -> ". $aQuery[0]['sumPosts'];?>
                    </td>
                </tr>

                <tr>
                    <td >
                        Име на Поста
                    </td>
                    <td>
                       Брой на коментиралите
                    </td>
                    <td>
                        Създадена от
                    </td>
                    <td >
                        На Дата
                    </td>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach($aQuery as $value) {
                        $postId = $value['id'];
                        $postName = $value['post_name'];
                        $postSumComments = $value['sumComments'];
                        $postCreator = $value['user_name'];
                        $postDateCreated = $value['date_created'];

                        echo "<tr>";
                            echo "<td><a href='?page=comments&post={$postId}'>{$postName} </a></td>";
                            echo "<td>{$postSumComments}";
                            echo "<td> {$postCreator}</td>";
                            echo "<td>{$postDateCreated}</td><br>";
                        echo "</tr>";

                    }
                ?>
            </tbody>
        </table>

        <?php
    }
}