<?php
/**
 * Created by PhpStorm.
 * User: Georgievi
 * Date: 16.5.2016 г.
 * Time: 18:17 ч.
 */

class TPLregistration extends Template {

    private function checkUser($user_name) {
        $conn = $this->connection;

        $query = "SELECT * FROM users WHERE user_name=:user_name";
        $conn = $conn->connect->prepare($query);
        $conn->bindParam(":user_name", $user_name, PDO::PARAM_STR);

        $conn->execute();

        return $conn->fetch(PDO::FETCH_ASSOC);
    }

    private function insert($user_name, $user_password) {
        $conn=$this->connection;

        $query = "INSERT INTO users (user_name, user_password) VALUES (?, ?)";
        $conn = $conn->connect->prepare($query);
        $conn->bindParam(1, $user_name, PDO::PARAM_STR);
        $conn->bindParam(2, $user_password, PDO::PARAM_STR);

        $conn->execute();
    }

    private function registration() {
        if(isset($this->aParams['registration_submit'])) {

            $userName = $this->aParams['username'];
            $userPassword = $this->aParams['password'];

            if($this->aParams['password'] == $this->aParams['re_password']) {
                $userPassword = md5($userPassword);
                if($this->checkUser($userName)) {
                    echo "Потребителското име е заето.";
                } else {
                    $this->insert($userName, $userPassword);
                }
            }else {
                echo "Паролите не съвпадат";
            }
        }
    }

    public function Title() {
        return "Registration";
    }

    public function Body() {

        echo $this->registration();

        ?>
            <h2>Регистрация</h2>
            <form action="" method="post">
                <input type="text" name="username" placeholder="Потребителско име" required><br>
                <input type="password" name="password" placeholder="Парола" required><br>
                <input type="password" name="re_password" placeholder="Повторете Паролата" required><br>
                <input type="submit" name="registration_submit" value="Регистрирай ме!">
            </form>
            <a href="?page=login"><<<<<< Връщане към страницата за вписване</a>
        <?php
    }
}