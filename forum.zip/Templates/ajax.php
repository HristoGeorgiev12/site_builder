<?php
/**
 * Created by PhpStorm.
 * User: Georgievi
 * Date: 25.5.2016 �.
 * Time: 20:35 �.
 */
session_start();
require_once "../Classes/Connect.class.php";
require_once "../Classes/Template.class.php";

function searchData($data) {
    $db = new Connect('forum');

    $query = "SELECT
                    p.id,
                    c.category_name,
                    p.post_name,
                    p.date_created,
                    u.user_name,
                    MATCH(post_name) AGAINST('$data*' IN BOOLEAN MODE) AS score
                FROM posts p
                INNER JOIN categories c
                ON p.category_id=c.id
                INNER JOIN users u
                ON u.id=p.user_id
                WHERE MATCH(post_name) AGAINST('$data*' IN BOOLEAN MODE)
                ORDER BY score DESC
                ";

    $connection = $db->connect->prepare($query);

    $connection->execute();
    $result = $connection->fetchAll(PDO::FETCH_ASSOC);


    return json_encode($result);
}

if(isset($_POST['submitSearch'])) {
    echo searchData($_POST["valueSearch"]);
}